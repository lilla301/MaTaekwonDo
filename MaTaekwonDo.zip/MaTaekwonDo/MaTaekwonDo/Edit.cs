﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaTaekwonDo
{
    public partial class Edit : Form
    {
        private Adatok d;
        public Edit(Adatok d)
        {
            InitializeComponent();
            textBoxEmail.Text = d.getEmail();
            comboBoxFelhszint.Text = d.getCategoryId().ToString();
            comboBoxKlub.Text = d.getKlub();
            comboBoxOvfok.Text = d.getOvfok();
            if (radioButtonFerfi.Checked)
            {
                radioButtonFerfi.Text=d.getFiu().ToString();
            }
            if (radioButtonNo.Checked)
            {
                radioButtonNo.Text = d.getFiu().ToString();
            }
            textBoxKnev.Text = d.getKnev();
            textBoxPwd.Text = d.getPwd();
            textBoxUname.Text = d.getfnev();
            textBoxVnev.Text = d.getVnev();
        }
        public Adatok getAdat()
        {
            return d;
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            d.setFnev(textBoxUname.Text);
            d.setPwd(textBoxPwd.Text);
            d.setCategoryId(Convert.ToInt32(comboBoxFelhszint.Text));
            d.setKlub(comboBoxKlub.Text);
            d.setOvfok(comboBoxOvfok.Text);
            d.setEmail(textBoxEmail.Text);
            if (radioButtonFerfi.Checked)
            {
                d.setFiu(Convert.ToBoolean(radioButtonFerfi.Text));
            }
            else
            {
                d.setFiu(Convert.ToBoolean(radioButtonNo.Text));
            }
            d.setVnev(textBoxVnev.Text);
            d.setKnev(textBoxKnev.Text);

        }
    }
}
