﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaTaekwonDo
{
    public class Adatok
    {
        List<Adatok> adat;
        int categoryID;
        int szemelyID;
        string fnev;
        string Knev;
        string Vnev;
        string pwd;
        string email;
        bool fiu;
        string klub;
        string ovfok;

        public Adatok(int categoryID, int szemelyID, string fnev, string pwd, string Vnev, string Knev, string email, bool fiu, string klub, string ovfok)
        {
            this.categoryID = categoryID;
            this.szemelyID = szemelyID;
            this.email = email;
            this.fiu = fiu;
            this.fnev = fnev;
            this.klub = klub;
            this.Knev = Knev;
            this.ovfok = ovfok;
            this.pwd = pwd;
            this.Vnev = Vnev;
        }
        public Adatok()
        {

        }
        public Adatok(int szemelyID)
        {
            this.categoryID = 0;
            this.szemelyID = szemelyID;
            this.fnev = string.Empty;
            this.pwd = string.Empty;
            this.Vnev = string.Empty;
            this.Knev = string.Empty;
            this.email = string.Empty;
            this.fiu = false;
            this.klub = string.Empty;
            this.ovfok = string.Empty;
        }
        #region gettek
        public int getCategoryId()
        {
            return categoryID;
        }
        public int getSzemelyID()
        {
            return szemelyID;
        }
        public string getfnev()
        {
            return fnev;
        }
        public string getKnev()
        {
            return Knev;
        }
        public string getVnev()
        {
            return Vnev;
        }
        public string getPwd()
        {
            return pwd;
        }
        public string getEmail()
        {
            return email;
        }
        public bool getFiu()
        {
            return fiu;
        }
        public string getKlub()
        {
            return klub;
        }
        public string getOvfok()
        {
            return ovfok;
        }
        #endregion
        #region settek
        public void setCategoryId(int categoryId)
        {
            this.categoryID = categoryId;
        }
        public void setSzemelyID(int szemelyID)
        {
            this.szemelyID = szemelyID;
        }
        public void setFnev(string fnev)
        {
            this.fnev = fnev;
        }
        public void setKnev(string Knev)
        {
            this.Knev = Knev;
        }
        public void setVnev(string Vnev)
        {
            this.Vnev = Vnev;
        }
        public void setPwd(string pwd)
        {
            this.pwd = pwd;
        }
        public void setEmail(string email)
        {
            this.email = email;
        }
        public void setFiu(bool ferfi)
        {
            this.fiu = ferfi;
        }
        public void setKlub(string klub)
        {
            this.klub = klub; ;
        }
        public void setOvfok(string ovfok)
        {
            this.ovfok = ovfok;
        }

        internal void setAdat(Adatok modositAdat)
        {
            this.categoryID = modositAdat.categoryID;
            this.szemelyID = modositAdat.szemelyID;
            this.fnev = modositAdat.fnev;
            this.Vnev = modositAdat.Vnev;
            this.Knev = modositAdat.Knev;
            this.pwd = modositAdat.pwd;
            this.email = modositAdat.email;
            this.fiu = modositAdat.fiu;
            this.klub = modositAdat.klub;
            this.ovfok = modositAdat.ovfok;
        }
        #endregion

      
    }
}
