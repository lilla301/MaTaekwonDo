﻿namespace MaTaekwonDo
{
    partial class Konyv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Konyv));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonRend = new System.Windows.Forms.Button();
            this.buttonKep = new System.Windows.Forms.Button();
            this.buttonSzotar = new System.Windows.Forms.Button();
            this.buttonJegyz = new System.Windows.Forms.Button();
            this.buttonVizsgaA = new System.Windows.Forms.Button();
            this.buttonTerem = new System.Windows.Forms.Button();
            this.buttonFejl = new System.Windows.Forms.Button();
            this.buttonTakt = new System.Windows.Forms.Button();
            this.buttonSzab = new System.Windows.Forms.Button();
            this.buttonKuzdelem = new System.Windows.Forms.Button();
            this.buttonTortech = new System.Windows.Forms.Button();
            this.buttonTor = new System.Windows.Forms.Button();
            this.buttonOnv = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.buttonSzabaly = new System.Windows.Forms.Button();
            this.buttonFormagy = new System.Windows.Forms.Button();
            this.buttonEroelm = new System.Windows.Forms.Button();
            this.buttonBaz = new System.Windows.Forms.Button();
            this.buttonMozg = new System.Windows.Forms.Button();
            this.buttonMaTorten = new System.Windows.Forms.Button();
            this.buttonElet = new System.Windows.Forms.Button();
            this.buttonTortent = new System.Windows.Forms.Button();
            this.buttonBev = new System.Windows.Forms.Button();
            this.buttonTan = new System.Windows.Forms.Button();
            this.buttonAjanlas = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonExit = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(4, 536);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(332, 22);
            this.label1.TabIndex = 6;
            this.label1.Text = "Készült az eredeti Nagykönyv alapján";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.buttonRend);
            this.groupBox2.Controls.Add(this.buttonKep);
            this.groupBox2.Controls.Add(this.buttonSzotar);
            this.groupBox2.Controls.Add(this.buttonJegyz);
            this.groupBox2.Controls.Add(this.buttonVizsgaA);
            this.groupBox2.Controls.Add(this.buttonTerem);
            this.groupBox2.Controls.Add(this.buttonFejl);
            this.groupBox2.Controls.Add(this.buttonTakt);
            this.groupBox2.Controls.Add(this.buttonSzab);
            this.groupBox2.Controls.Add(this.buttonKuzdelem);
            this.groupBox2.Controls.Add(this.buttonTortech);
            this.groupBox2.Controls.Add(this.buttonTor);
            this.groupBox2.Controls.Add(this.buttonOnv);
            this.groupBox2.Controls.Add(this.button14);
            this.groupBox2.Controls.Add(this.buttonSzabaly);
            this.groupBox2.Controls.Add(this.buttonFormagy);
            this.groupBox2.Controls.Add(this.buttonEroelm);
            this.groupBox2.Controls.Add(this.buttonBaz);
            this.groupBox2.Controls.Add(this.buttonMozg);
            this.groupBox2.Controls.Add(this.buttonMaTorten);
            this.groupBox2.Controls.Add(this.buttonElet);
            this.groupBox2.Controls.Add(this.buttonTortent);
            this.groupBox2.Controls.Add(this.buttonBev);
            this.groupBox2.Controls.Add(this.buttonTan);
            this.groupBox2.Controls.Add(this.buttonAjanlas);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox2.Location = new System.Drawing.Point(331, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(642, 568);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tartalom";
            // 
            // buttonRend
            // 
            this.buttonRend.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRend.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRend.Location = new System.Drawing.Point(446, 341);
            this.buttonRend.Name = "buttonRend";
            this.buttonRend.Size = new System.Drawing.Size(190, 40);
            this.buttonRend.TabIndex = 0;
            this.buttonRend.Text = "Az övfokozatok rendje";
            this.buttonRend.UseVisualStyleBackColor = true;
            this.buttonRend.Click += new System.EventHandler(this.buttonRend_Click);
            // 
            // buttonKep
            // 
            this.buttonKep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonKep.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKep.Location = new System.Drawing.Point(503, 525);
            this.buttonKep.Name = "buttonKep";
            this.buttonKep.Size = new System.Drawing.Size(133, 37);
            this.buttonKep.TabIndex = 0;
            this.buttonKep.Text = "Képmelléklet";
            this.buttonKep.UseVisualStyleBackColor = true;
            this.buttonKep.Click += new System.EventHandler(this.buttonKep_Click);
            // 
            // buttonSzotar
            // 
            this.buttonSzotar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSzotar.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSzotar.Location = new System.Drawing.Point(482, 479);
            this.buttonSzotar.Name = "buttonSzotar";
            this.buttonSzotar.Size = new System.Drawing.Size(154, 40);
            this.buttonSzotar.TabIndex = 0;
            this.buttonSzotar.Text = "Koreai szakszótár";
            this.buttonSzotar.UseVisualStyleBackColor = true;
            this.buttonSzotar.Click += new System.EventHandler(this.buttonSzotar_Click);
            // 
            // buttonJegyz
            // 
            this.buttonJegyz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonJegyz.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonJegyz.Location = new System.Drawing.Point(482, 433);
            this.buttonJegyz.Name = "buttonJegyz";
            this.buttonJegyz.Size = new System.Drawing.Size(154, 40);
            this.buttonJegyz.TabIndex = 0;
            this.buttonJegyz.Text = "Orvosi jegyzetek";
            this.buttonJegyz.UseVisualStyleBackColor = true;
            this.buttonJegyz.Click += new System.EventHandler(this.buttonJegyz_Click);
            // 
            // buttonVizsgaA
            // 
            this.buttonVizsgaA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonVizsgaA.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonVizsgaA.Location = new System.Drawing.Point(446, 387);
            this.buttonVizsgaA.Name = "buttonVizsgaA";
            this.buttonVizsgaA.Size = new System.Drawing.Size(190, 40);
            this.buttonVizsgaA.TabIndex = 0;
            this.buttonVizsgaA.Text = "Részletes vizsgaanyag";
            this.buttonVizsgaA.UseVisualStyleBackColor = true;
            this.buttonVizsgaA.Click += new System.EventHandler(this.buttonVizsgaA_Click);
            // 
            // buttonTerem
            // 
            this.buttonTerem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTerem.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTerem.Location = new System.Drawing.Point(537, 295);
            this.buttonTerem.Name = "buttonTerem";
            this.buttonTerem.Size = new System.Drawing.Size(99, 40);
            this.buttonTerem.TabIndex = 0;
            this.buttonTerem.Text = "Edzőterem";
            this.buttonTerem.UseVisualStyleBackColor = true;
            this.buttonTerem.Click += new System.EventHandler(this.buttonTerem_Click);
            // 
            // buttonFejl
            // 
            this.buttonFejl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFejl.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFejl.Location = new System.Drawing.Point(423, 249);
            this.buttonFejl.Name = "buttonFejl";
            this.buttonFejl.Size = new System.Drawing.Size(213, 40);
            this.buttonFejl.TabIndex = 0;
            this.buttonFejl.Text = "Speciális képességfejlesztés";
            this.buttonFejl.UseVisualStyleBackColor = true;
            this.buttonFejl.Click += new System.EventHandler(this.buttonFejl_Click);
            // 
            // buttonTakt
            // 
            this.buttonTakt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTakt.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTakt.Location = new System.Drawing.Point(482, 203);
            this.buttonTakt.Name = "buttonTakt";
            this.buttonTakt.Size = new System.Drawing.Size(154, 40);
            this.buttonTakt.TabIndex = 0;
            this.buttonTakt.Text = "Versenytaktika";
            this.buttonTakt.UseVisualStyleBackColor = true;
            this.buttonTakt.Click += new System.EventHandler(this.buttonTakt_Click);
            // 
            // buttonSzab
            // 
            this.buttonSzab.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSzab.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSzab.Location = new System.Drawing.Point(411, 157);
            this.buttonSzab.Name = "buttonSzab";
            this.buttonSzab.Size = new System.Drawing.Size(225, 40);
            this.buttonSzab.TabIndex = 0;
            this.buttonSzab.Text = "A küzdelem versenyszabályai";
            this.buttonSzab.UseVisualStyleBackColor = true;
            this.buttonSzab.Click += new System.EventHandler(this.buttonSzab_Click);
            // 
            // buttonKuzdelem
            // 
            this.buttonKuzdelem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonKuzdelem.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKuzdelem.Location = new System.Drawing.Point(479, 111);
            this.buttonKuzdelem.Name = "buttonKuzdelem";
            this.buttonKuzdelem.Size = new System.Drawing.Size(157, 40);
            this.buttonKuzdelem.TabIndex = 0;
            this.buttonKuzdelem.Text = "Szabad küzdelem";
            this.buttonKuzdelem.UseVisualStyleBackColor = true;
            this.buttonKuzdelem.Click += new System.EventHandler(this.buttonKuzdelem_Click);
            // 
            // buttonTortech
            // 
            this.buttonTortech.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTortech.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTortech.Location = new System.Drawing.Point(371, 65);
            this.buttonTortech.Name = "buttonTortech";
            this.buttonTortech.Size = new System.Drawing.Size(265, 40);
            this.buttonTortech.TabIndex = 0;
            this.buttonTortech.Text = "A töréstechnika versenyszabályai";
            this.buttonTortech.UseVisualStyleBackColor = true;
            this.buttonTortech.Click += new System.EventHandler(this.buttonTortech_Click);
            // 
            // buttonTor
            // 
            this.buttonTor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTor.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonTor.Location = new System.Drawing.Point(467, 19);
            this.buttonTor.Name = "buttonTor";
            this.buttonTor.Size = new System.Drawing.Size(169, 40);
            this.buttonTor.TabIndex = 0;
            this.buttonTor.Text = "Töréstechnika";
            this.buttonTor.UseVisualStyleBackColor = true;
            this.buttonTor.Click += new System.EventHandler(this.buttonTor_Click);
            // 
            // buttonOnv
            // 
            this.buttonOnv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOnv.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonOnv.Location = new System.Drawing.Point(6, 433);
            this.buttonOnv.Name = "buttonOnv";
            this.buttonOnv.Size = new System.Drawing.Size(170, 40);
            this.buttonOnv.TabIndex = 0;
            this.buttonOnv.Text = "Önvédelmi technikák";
            this.buttonOnv.UseVisualStyleBackColor = true;
            this.buttonOnv.Click += new System.EventHandler(this.buttonOnv_Click);
            // 
            // button14
            // 
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(6, 387);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(170, 40);
            this.button14.TabIndex = 0;
            this.button14.Text = "Formai küzdelem";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // buttonSzabaly
            // 
            this.buttonSzabaly.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSzabaly.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSzabaly.Location = new System.Drawing.Point(6, 525);
            this.buttonSzabaly.Name = "buttonSzabaly";
            this.buttonSzabaly.Size = new System.Drawing.Size(269, 37);
            this.buttonSzabaly.TabIndex = 0;
            this.buttonSzabaly.Text = "A formagyakorlat versenyszabályai";
            this.buttonSzabaly.UseVisualStyleBackColor = true;
            this.buttonSzabaly.Click += new System.EventHandler(this.buttonSzabaly_Click);
            // 
            // buttonFormagy
            // 
            this.buttonFormagy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFormagy.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFormagy.Location = new System.Drawing.Point(6, 479);
            this.buttonFormagy.Name = "buttonFormagy";
            this.buttonFormagy.Size = new System.Drawing.Size(170, 40);
            this.buttonFormagy.TabIndex = 0;
            this.buttonFormagy.Text = "Formagyakorlat";
            this.buttonFormagy.UseVisualStyleBackColor = true;
            this.buttonFormagy.Click += new System.EventHandler(this.buttonFormagy_Click);
            // 
            // buttonEroelm
            // 
            this.buttonEroelm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEroelm.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEroelm.Location = new System.Drawing.Point(6, 341);
            this.buttonEroelm.Name = "buttonEroelm";
            this.buttonEroelm.Size = new System.Drawing.Size(227, 40);
            this.buttonEroelm.TabIndex = 0;
            this.buttonEroelm.Text = "Erő és gyorsaság elmélete";
            this.buttonEroelm.UseVisualStyleBackColor = true;
            this.buttonEroelm.Click += new System.EventHandler(this.buttonEroelm_Click);
            // 
            // buttonBaz
            // 
            this.buttonBaz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBaz.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBaz.Location = new System.Drawing.Point(6, 295);
            this.buttonBaz.Name = "buttonBaz";
            this.buttonBaz.Size = new System.Drawing.Size(227, 40);
            this.buttonBaz.TabIndex = 0;
            this.buttonBaz.Text = "Bázis, vagy alapgyakorlatok";
            this.buttonBaz.UseVisualStyleBackColor = true;
            this.buttonBaz.Click += new System.EventHandler(this.buttonBaz_Click);
            // 
            // buttonMozg
            // 
            this.buttonMozg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMozg.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMozg.Location = new System.Drawing.Point(6, 249);
            this.buttonMozg.Name = "buttonMozg";
            this.buttonMozg.Size = new System.Drawing.Size(227, 40);
            this.buttonMozg.TabIndex = 0;
            this.buttonMozg.Text = "A Taekwon-do mozgásanyaga";
            this.buttonMozg.UseVisualStyleBackColor = true;
            this.buttonMozg.Click += new System.EventHandler(this.buttonMozg_Click);
            // 
            // buttonMaTorten
            // 
            this.buttonMaTorten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMaTorten.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMaTorten.Location = new System.Drawing.Point(6, 111);
            this.buttonMaTorten.Name = "buttonMaTorten";
            this.buttonMaTorten.Size = new System.Drawing.Size(241, 40);
            this.buttonMaTorten.TabIndex = 0;
            this.buttonMaTorten.Text = "A magyar Taekwon-do története";
            this.buttonMaTorten.UseVisualStyleBackColor = true;
            this.buttonMaTorten.Click += new System.EventHandler(this.buttonMaTorten_Click);
            // 
            // buttonElet
            // 
            this.buttonElet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonElet.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonElet.Location = new System.Drawing.Point(6, 203);
            this.buttonElet.Name = "buttonElet";
            this.buttonElet.Size = new System.Drawing.Size(99, 40);
            this.buttonElet.TabIndex = 0;
            this.buttonElet.Text = "Életpontok";
            this.buttonElet.UseVisualStyleBackColor = true;
            this.buttonElet.Click += new System.EventHandler(this.buttonElet_Click);
            // 
            // buttonTortent
            // 
            this.buttonTortent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTortent.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTortent.Location = new System.Drawing.Point(6, 65);
            this.buttonTortent.Name = "buttonTortent";
            this.buttonTortent.Size = new System.Drawing.Size(185, 40);
            this.buttonTortent.TabIndex = 0;
            this.buttonTortent.Text = "A Taekwon-do története";
            this.buttonTortent.UseVisualStyleBackColor = true;
            this.buttonTortent.Click += new System.EventHandler(this.buttonTortent_Click);
            // 
            // buttonBev
            // 
            this.buttonBev.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBev.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonBev.Location = new System.Drawing.Point(111, 18);
            this.buttonBev.Name = "buttonBev";
            this.buttonBev.Size = new System.Drawing.Size(110, 40);
            this.buttonBev.TabIndex = 0;
            this.buttonBev.Text = "Bevezető";
            this.buttonBev.UseVisualStyleBackColor = true;
            this.buttonBev.Click += new System.EventHandler(this.buttonBev_Click);
            // 
            // buttonTan
            // 
            this.buttonTan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTan.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTan.Location = new System.Drawing.Point(6, 157);
            this.buttonTan.Name = "buttonTan";
            this.buttonTan.Size = new System.Drawing.Size(170, 40);
            this.buttonTan.TabIndex = 0;
            this.buttonTan.Text = "A Taekwon-do tanai";
            this.buttonTan.UseVisualStyleBackColor = true;
            this.buttonTan.Click += new System.EventHandler(this.buttonTan_Click);
            // 
            // buttonAjanlas
            // 
            this.buttonAjanlas.BackColor = System.Drawing.Color.Transparent;
            this.buttonAjanlas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAjanlas.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonAjanlas.Location = new System.Drawing.Point(6, 19);
            this.buttonAjanlas.Name = "buttonAjanlas";
            this.buttonAjanlas.Size = new System.Drawing.Size(99, 39);
            this.buttonAjanlas.TabIndex = 0;
            this.buttonAjanlas.Text = "Ajánlás";
            this.buttonAjanlas.UseVisualStyleBackColor = false;
            this.buttonAjanlas.Click += new System.EventHandler(this.buttonAjanlas_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(8, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(291, 446);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Transparent;
            this.buttonExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonExit.BackgroundImage")));
            this.buttonExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Location = new System.Drawing.Point(979, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(33, 30);
            this.buttonExit.TabIndex = 7;
            this.buttonExit.UseVisualStyleBackColor = false;
            // 
            // Konyv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1024, 567);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Konyv";
            this.Text = "Konyv";
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion


        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonRend;
        private System.Windows.Forms.Button buttonKep;
        private System.Windows.Forms.Button buttonSzotar;
        private System.Windows.Forms.Button buttonJegyz;
        private System.Windows.Forms.Button buttonVizsgaA;
        private System.Windows.Forms.Button buttonTerem;
        private System.Windows.Forms.Button buttonFejl;
        private System.Windows.Forms.Button buttonTakt;
        private System.Windows.Forms.Button buttonSzab;
        private System.Windows.Forms.Button buttonKuzdelem;
        private System.Windows.Forms.Button buttonTortech;
        private System.Windows.Forms.Button buttonTor;
        private System.Windows.Forms.Button buttonOnv;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button buttonSzabaly;
        private System.Windows.Forms.Button buttonFormagy;
        private System.Windows.Forms.Button buttonEroelm;
        private System.Windows.Forms.Button buttonBaz;
        private System.Windows.Forms.Button buttonMozg;
        private System.Windows.Forms.Button buttonMaTorten;
        private System.Windows.Forms.Button buttonElet;
        private System.Windows.Forms.Button buttonTortent;
        private System.Windows.Forms.Button buttonBev;
        private System.Windows.Forms.Button buttonTan;
        private System.Windows.Forms.Button buttonAjanlas;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonExit;
    }
}