﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaTaekwonDo
{
    public partial class Bejelentkezes : Form
    {
        bool adminE = false;
        public Bejelentkezes()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            Index i = new Index();
            i.Show();
            this.Hide();
        }

        private void buttonLog_Click(object sender, EventArgs e)
        {
            Adatbazis a = new Adatbazis();
            MySQLDataInterface mdi = a.kapcsolodas();
            mdi.open();
            string query = "SELECT COUNT(*) FROM user WHERE felhasznalonev= \""+textBoxUname.Text+"\" and jelszo =\""+textBoxPwd.Text+"\"";
            string result = mdi.executeScalarQuery(query);
            if (result == "1")
            {
                MessageBox.Show("Sikeres bejelentkezés :)", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Felhasznalok fh = new Felhasznalok();
                fh.Show();
                this.Hide();
            }
             else
             {
                 MessageBox.Show("Hibás felhasználónév vagy jelszó", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
             }


        }
       
    }
}
