﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;

namespace MaTaekwonDo
{
    public partial class Felhasznalok : Form
    {
        #region Listview esetén
        /* MySqlConnection connection=new MySqlConnection();
         Adatbazis a = new Adatbazis();
         Adatok ad;
         Edit ed;
         List<Adatok> adat;*/
        #endregion
        private MySQLDataInterface mdi;
        private DataTable category;
        private DataTable user;
        bool modositottE = false;
        Adatbazis a = new Adatbazis();

        public Felhasznalok()
        {
            InitializeComponent();
            #region Listview esetén
            //adat = new List<Adatok>();

            /*Listview Category
            listViewCategory.Columns.Add("ID");
            listViewCategory.Columns.Add("Megnevezés");
            listViewCategory.Columns[0].Width = 30;
            listViewCategory.Columns[1].Width = 100;
            listViewCategory.View = View.Details;
            listViewCategory.FullRowSelect = true;
            Controls.Add(listViewCategory);

            listViewAdatok.Columns.Add("Felhasználói szint");
            listViewAdatok.Columns.Add("SzemélyID");
            listViewAdatok.Columns.Add("Felhasználónév");
            listViewAdatok.Columns.Add("Jelszó");
            listViewAdatok.Columns.Add("Vezetéknév");
            listViewAdatok.Columns.Add("Keresztnév");
            listViewAdatok.Columns.Add("Email cím");
            listViewAdatok.Columns.Add("Neme");
            listViewAdatok.Columns.Add("Klub");
            listViewAdatok.Columns.Add("Övfokozat");
            listViewAdatok.Columns[0].Width = 100;
            listViewAdatok.Columns[1].Width = 100;
            listViewAdatok.Columns[2].Width = 100;
            listViewAdatok.Columns[3].Width = 100;
            listViewAdatok.Columns[4].Width = 100;
            listViewAdatok.Columns[5].Width = 100;
            listViewAdatok.Columns[6].Width = 100;
            listViewAdatok.Columns[7].Width = 100;
            listViewAdatok.Columns[8].Width = 100;
            listViewAdatok.Columns[9].Width = 100;
            listViewAdatok.View = View.Details;
            listViewAdatok.FullRowSelect = true;
            Controls.Add(listViewAdatok*/
            #endregion
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            if (modositottE)
            {
                if(MessageBox.Show("Nem mentett módosításai vannak. Biztosan ki szeretne lépni?", "Kilépés", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Application.Exit();
                }
            }
            else
            {
                Application.Exit();
            }
            
        }
        private void Felhasznalok_Load(object sender, EventArgs e)
        {
            #region listview esetén
            /*
            //buttonFeltolt.Visible = false;
            try
            {
                a.KategoriaAdatbazis();
            }
            catch (Exception ex)
            {
                
            }
            feltoltAdatokkal();
            try
            {
                a.AdatokAdatbazis();
            }
            catch (Exception ex)
            {
                errorProviderBetoltes.SetError(listViewAdatok, ex.Message);
            }
            feltoltListviewtAdattal();*/
            #endregion
            #region datagridview feltöltése
            mdi = a.kapcsolodas();
            mdi.open();
            category = mdi.getToDataTable("SELECT * FROM category");
            dataGridViewCategory.DataSource = category;
            dataGridViewCategory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewCategory.Columns[0].Width = 20;
            dataGridViewCategory.Columns[1].Width = 70;
            buttonBetolt.Visible = false;
            buttonMentes.Visible = false;
            #endregion
            buttonUj.Visible = false;
            buttonEdit.Visible = false;
            buttonDel.Visible = false;
            buttonMentes.Visible = false;
            buttonBetolt.Visible = true;
        }
        #region listview esetén feltoltes
        /*private void feltoltListviewtAdattal()
        {
           
            List<Adatok> adat = a.getAdatok();
            foreach (Adatok d in adat)
            {
                ListViewItem lvi = new ListViewItem(d.getCategoryId().ToString());
                lvi.SubItems.Add(d.getSzemelyID().ToString());
                lvi.SubItems.Add(d.getfnev());
                lvi.SubItems.Add(d.getPwd());
                lvi.SubItems.Add(d.getVnev());
                lvi.SubItems.Add(d.getKnev());
                lvi.SubItems.Add(d.getEmail());
                //if fiú bool
                lvi.SubItems.Add(d.getFiu().ToString());
                lvi.SubItems.Add(d.getKlub());
                lvi.SubItems.Add(d.getOvfok());
                listViewAdatok.Items.Add(lvi);
            }
            
        }

        private void feltoltAdatokkal()
        {
            List<Kategoria> kategoriak = a.getKategoriak();
            foreach (Kategoria k in kategoriak)
            {
                ListViewItem lvi = new ListViewItem(k.getId().ToString());
                lvi.SubItems.Add(k.getName());
                listViewCategory.Items.Add(lvi);
            }
        }*/
        #endregion
        private void buttonUj_Click(object sender, EventArgs e)
        {
            #region listview esetén
            /*ListViewItem newItem = new ListViewItem();
            if (listViewAdatok.Items.Count == 0)
            {
                ad = new Adatok();
                ed = new Edit(ad);
                if (ed.ShowDialog() == DialogResult.OK)
                {
                    ad = ed.getAdat();
                    newItem.Text = ad.getCategoryId().ToString();
                    newItem.SubItems.Add(ad.getSzemelyID().ToString());
                    newItem.SubItems.Add(ad.getfnev());
                    newItem.SubItems.Add(ad.getPwd());
                    newItem.SubItems.Add(ad.getVnev());
                    newItem.SubItems.Add(ad.getKnev());
                    newItem.SubItems.Add(ad.getEmail());
                    newItem.SubItems.Add(ad.getFiu().ToString());
                    newItem.SubItems.Add(ad.getKlub());
                    newItem.SubItems.Add(ad.getOvfok());
                    listViewAdatok.Items.Add(newItem);

                    a.hozzaadListahozAdatot(ad);
                    try
                    {
                        a.ujAdat(ad);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.Message);
                        errorProviderBetoltes.SetError(buttonUj, "Adatbázis hiba");
                    }
                }
            }
            else
            {
                int ujSzemelyID = a.getNextSzemelyID();
                ad = new Adatok(ujSzemelyID);
                ed = new Edit(ad);

                if (ed.ShowDialog() == DialogResult.OK)
                {
                    ad = ed.getAdat();
                    newItem.Text = ad.getCategoryId().ToString();
                    newItem.SubItems.Add(ad.getSzemelyID().ToString());
                    newItem.SubItems.Add(ad.getfnev());
                    newItem.SubItems.Add(ad.getPwd());
                    newItem.SubItems.Add(ad.getVnev());
                    newItem.SubItems.Add(ad.getKnev());
                    newItem.SubItems.Add(ad.getEmail());
                    newItem.SubItems.Add(ad.getFiu().ToString());
                    newItem.SubItems.Add(ad.getKlub());
                    newItem.SubItems.Add(ad.getOvfok());
                    listViewAdatok.Items.Add(newItem);

                    a.hozzaadListahozAdatot(ad);
                    try
                    {
                        a.ujAdat(ad);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.Message);
                        errorProviderBetoltes.SetError(buttonUj, "Adatbázis hiba");
                    }
                }
            }*/
            #endregion
            buttonDel.Visible = false;
            buttonMentes.Visible = true;
            buttonUj.Visible = false;
            buttonEdit.Visible = false;
            buttonBetolt.Visible = false;

            dataGridViewUser.AllowUserToAddRows = true;
            dataGridViewUser.SelectionMode = DataGridViewSelectionMode.CellSelect;
            //sorok megszámolása
            int sor = dataGridViewUser.Rows.Count - 1;
            //utolsó sor kijelölése (itt adunk hozzá)
            dataGridViewUser.Rows[sor].Cells[1].Selected = true;
            //csak azt a sort írhatjuk, amelyikben az adatokat vesszük fel
            dataGridViewUser.ReadOnly = false;
            for(int i = 0; i < sor; i++)
            {
                dataGridViewUser.Rows[i].ReadOnly = true;

                //lista végére görgetünk ami az utolsó sornak felel meg
                dataGridViewUser.FirstDisplayedScrollingRowIndex = sor;
                dataGridViewUser.Columns[1].ReadOnly = true;

                modositottE = true;
            }
            
           
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            dataGridViewUser.ReadOnly = false;
            dataGridViewUser.AllowUserToAddRows = false;
            buttonMentes.Visible = true;
            buttonEdit.Visible = false;
            buttonDel.Visible = false;
            buttonBetolt.Visible = false;
            buttonUj.Visible = false;
            modositottE = false;
            dataGridViewUser.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }

        private void buttonBetolt_Click(object sender, EventArgs e)
        {
            user = mdi.getToDataTable("SELECT * FROM user");
            dataGridViewUser.DataSource = user;
            dataGridViewUser.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewUser.Columns[0].Width = 20;
            dataGridViewUser.Columns[1].Width = 20;
            dataGridViewUser.AllowUserToDeleteRows = false;
            dataGridViewUser.ReadOnly = true;
            buttonBetolt.Enabled = false;
            buttonUj.Visible = true;
            buttonEdit.Visible = true;
            buttonDel.Visible = true;
            buttonMentes.Visible = false;
        }

        private void dataGridViewUser_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            modositottE = true;
            buttonMentes.Visible = true;
        }

        private void buttonMentes_Click(object sender, EventArgs e)
        {
            if (modositottE)
            {
                mdi.frissitAdatokat(user);
                buttonMentes.Visible = false;
                buttonUj.Visible = true;
                buttonBetolt.Visible = false;
                buttonEdit.Visible = true;
                buttonDel.Visible = true;

            }
            else
            {
                MessageBox.Show("Nem történt változás, ami miatt menteni kellene");
                buttonMentes.Visible = false;
            }
        }

        private void dataGridViewUser_DefaultValuesNeeded(object sender, DataGridViewRowEventArgs e)
        {
            Adatbazis ujID = new Adatbazis();
            MySQLDataInterface mdiUjId = ujID.kapcsolodas();
            mdiUjId.open();
            int max;
            bool siker = int.TryParse(mdiUjId.executeScalarQuery("SELECT MAX(szemelyID) FROM user"), out max);
            if (!siker)
            {
                MessageBox.Show("Nem lehet megállapítani a következő ID-t");
                return;
            }
            mdiUjId.close();
            //Azonosító hozzáadás
            e.Row.Cells[1].Value = max+1;
        }

        private void buttonDel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Biztosan törölni szeretné a kijelölt adatot? Az adat az adatbázisból is törlődni fog!", "Törlés", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    int sor = dataGridViewUser.SelectedRows[0].Index;
                    dataGridViewUser.Rows.RemoveAt(sor);
                    buttonMentes.Visible = true;
                    modositottE = true;
                    dataGridViewUser.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                }
                catch(Exception ex)
                {
                    return;
                }
            }
        }
    }
}
