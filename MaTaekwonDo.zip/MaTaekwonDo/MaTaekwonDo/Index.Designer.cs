﻿namespace MaTaekwonDo
{
    partial class Index
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Index));
            this.buttonExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonLogin = new System.Windows.Forms.Button();
            this.buttonReg = new System.Windows.Forms.Button();
            this.buttonLicense = new System.Windows.Forms.Button();
            this.buttonDig = new System.Windows.Forms.Button();
            this.buttonWebOldal = new System.Windows.Forms.Button();
            this.toolTipLogin = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Transparent;
            this.buttonExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonExit.BackgroundImage")));
            this.buttonExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Location = new System.Drawing.Point(972, 7);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(40, 37);
            this.buttonExit.TabIndex = 0;
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Cambria", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(13, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(272, 43);
            this.label1.TabIndex = 1;
            this.label1.Text = "MaTaekwonDo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Cambria", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(17, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(934, 32);
            this.label2.TabIndex = 3;
            this.label2.Text = "\"A győzelemért az embernek mindenekelőtt tudnia kell önmagát legyőzni...\"";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Cambria", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(67, 243);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(692, 32);
            this.label3.TabIndex = 4;
            this.label3.Text = "\"A harcosnak, ki megacélozza testét, lelke is nemesedik,";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Cambria", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(260, 275);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(752, 32);
            this.label4.TabIndex = 5;
            this.label4.Text = "és megvalósítja test, lélek és szellem tökéletes összhangját...\"";
            // 
            // buttonLogin
            // 
            this.buttonLogin.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonLogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonLogin.BackgroundImage")));
            this.buttonLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLogin.Location = new System.Drawing.Point(12, 391);
            this.buttonLogin.Name = "buttonLogin";
            this.buttonLogin.Size = new System.Drawing.Size(191, 173);
            this.buttonLogin.TabIndex = 6;
            this.buttonLogin.UseVisualStyleBackColor = false;
            this.buttonLogin.Click += new System.EventHandler(this.buttonLogin_Click);
            // 
            // buttonReg
            // 
            this.buttonReg.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonReg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonReg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonReg.Location = new System.Drawing.Point(209, 391);
            this.buttonReg.Name = "buttonReg";
            this.buttonReg.Size = new System.Drawing.Size(191, 173);
            this.buttonReg.TabIndex = 6;
            this.buttonReg.UseVisualStyleBackColor = false;
            this.buttonReg.Click += new System.EventHandler(this.buttonReg_Click);
            // 
            // buttonLicense
            // 
            this.buttonLicense.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonLicense.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonLicense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLicense.Location = new System.Drawing.Point(821, 391);
            this.buttonLicense.Name = "buttonLicense";
            this.buttonLicense.Size = new System.Drawing.Size(191, 173);
            this.buttonLicense.TabIndex = 6;
            this.buttonLicense.UseVisualStyleBackColor = false;
            // 
            // buttonDig
            // 
            this.buttonDig.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonDig.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonDig.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDig.Location = new System.Drawing.Point(624, 391);
            this.buttonDig.Name = "buttonDig";
            this.buttonDig.Size = new System.Drawing.Size(191, 173);
            this.buttonDig.TabIndex = 6;
            this.buttonDig.UseVisualStyleBackColor = false;
            // 
            // buttonWebOldal
            // 
            this.buttonWebOldal.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.buttonWebOldal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonWebOldal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonWebOldal.Location = new System.Drawing.Point(417, 391);
            this.buttonWebOldal.Name = "buttonWebOldal";
            this.buttonWebOldal.Size = new System.Drawing.Size(191, 173);
            this.buttonWebOldal.TabIndex = 6;
            this.buttonWebOldal.UseVisualStyleBackColor = false;
            this.buttonWebOldal.Click += new System.EventHandler(this.buttonWebOldal_Click);
            // 
            // Index
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1024, 576);
            this.Controls.Add(this.buttonWebOldal);
            this.Controls.Add(this.buttonDig);
            this.Controls.Add(this.buttonLicense);
            this.Controls.Add(this.buttonReg);
            this.Controls.Add(this.buttonLogin);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonExit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Index";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MaTaekwondo";
            this.Load += new System.EventHandler(this.Index_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonLogin;
        private System.Windows.Forms.Button buttonReg;
        private System.Windows.Forms.Button buttonLicense;
        private System.Windows.Forms.Button buttonDig;
        private System.Windows.Forms.Button buttonWebOldal;
        private System.Windows.Forms.ToolTip toolTipLogin;
    }
}

