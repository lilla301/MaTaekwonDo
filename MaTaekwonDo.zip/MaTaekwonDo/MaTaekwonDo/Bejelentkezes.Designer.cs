﻿namespace MaTaekwonDo
{
    partial class Bejelentkezes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bejelentkezes));
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonSzasz = new System.Windows.Forms.Button();
            this.buttonSzalay = new System.Windows.Forms.Button();
            this.buttonHarmat = new System.Windows.Forms.Button();
            this.buttonMate = new System.Windows.Forms.Button();
            this.buttonSolti = new System.Windows.Forms.Button();
            this.buttonLog = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.textBoxUname = new System.Windows.Forms.TextBox();
            this.textBoxPwd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Transparent;
            this.buttonExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonExit.BackgroundImage")));
            this.buttonExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Location = new System.Drawing.Point(972, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(40, 37);
            this.buttonExit.TabIndex = 1;
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonSzasz
            // 
            this.buttonSzasz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonSzasz.BackgroundImage")));
            this.buttonSzasz.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonSzasz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSzasz.Location = new System.Drawing.Point(12, 12);
            this.buttonSzasz.Name = "buttonSzasz";
            this.buttonSzasz.Size = new System.Drawing.Size(162, 239);
            this.buttonSzasz.TabIndex = 2;
            this.buttonSzasz.UseVisualStyleBackColor = true;
            // 
            // buttonSzalay
            // 
            this.buttonSzalay.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonSzalay.BackgroundImage")));
            this.buttonSzalay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonSzalay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSzalay.Location = new System.Drawing.Point(180, 12);
            this.buttonSzalay.Name = "buttonSzalay";
            this.buttonSzalay.Size = new System.Drawing.Size(162, 239);
            this.buttonSzalay.TabIndex = 2;
            this.buttonSzalay.UseVisualStyleBackColor = true;
            // 
            // buttonHarmat
            // 
            this.buttonHarmat.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonHarmat.BackgroundImage")));
            this.buttonHarmat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonHarmat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHarmat.Location = new System.Drawing.Point(381, 12);
            this.buttonHarmat.Name = "buttonHarmat";
            this.buttonHarmat.Size = new System.Drawing.Size(206, 239);
            this.buttonHarmat.TabIndex = 2;
            this.buttonHarmat.UseVisualStyleBackColor = true;
            // 
            // buttonMate
            // 
            this.buttonMate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonMate.BackgroundImage")));
            this.buttonMate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonMate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMate.Location = new System.Drawing.Point(621, 12);
            this.buttonMate.Name = "buttonMate";
            this.buttonMate.Size = new System.Drawing.Size(162, 239);
            this.buttonMate.TabIndex = 2;
            this.buttonMate.UseVisualStyleBackColor = true;
            // 
            // buttonSolti
            // 
            this.buttonSolti.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonSolti.BackgroundImage")));
            this.buttonSolti.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonSolti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSolti.Location = new System.Drawing.Point(789, 12);
            this.buttonSolti.Name = "buttonSolti";
            this.buttonSolti.Size = new System.Drawing.Size(162, 239);
            this.buttonSolti.TabIndex = 2;
            this.buttonSolti.UseVisualStyleBackColor = true;
            // 
            // buttonLog
            // 
            this.buttonLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.buttonLog.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLog.Font = new System.Drawing.Font("Cambria", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonLog.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonLog.Location = new System.Drawing.Point(381, 515);
            this.buttonLog.Name = "buttonLog";
            this.buttonLog.Size = new System.Drawing.Size(206, 47);
            this.buttonLog.TabIndex = 3;
            this.buttonLog.Text = "Bejelentkezés";
            this.buttonLog.UseVisualStyleBackColor = false;
            this.buttonLog.Click += new System.EventHandler(this.buttonLog_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.buttonBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBack.Font = new System.Drawing.Font("Cambria", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonBack.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonBack.Location = new System.Drawing.Point(12, 515);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(162, 47);
            this.buttonBack.TabIndex = 4;
            this.buttonBack.Text = "Vissza";
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // textBoxUname
            // 
            this.textBoxUname.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.textBoxUname.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxUname.Location = new System.Drawing.Point(381, 329);
            this.textBoxUname.Name = "textBoxUname";
            this.textBoxUname.Size = new System.Drawing.Size(206, 32);
            this.textBoxUname.TabIndex = 1;
            // 
            // textBoxPwd
            // 
            this.textBoxPwd.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.textBoxPwd.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxPwd.Location = new System.Drawing.Point(381, 367);
            this.textBoxPwd.Name = "textBoxPwd";
            this.textBoxPwd.Size = new System.Drawing.Size(206, 32);
            this.textBoxPwd.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(154, 333);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 28);
            this.label1.TabIndex = 5;
            this.label1.Text = "Felhasználónév:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(154, 371);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 28);
            this.label2.TabIndex = 5;
            this.label2.Text = "Jelszó:";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.linkLabel1.Location = new System.Drawing.Point(684, 336);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(267, 25);
            this.linkLabel1.TabIndex = 6;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Elfelejtetted a jelszavadat?";
            // 
            // Bejelentkezes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1024, 576);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxPwd);
            this.Controls.Add(this.textBoxUname);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.buttonLog);
            this.Controls.Add(this.buttonSolti);
            this.Controls.Add(this.buttonMate);
            this.Controls.Add(this.buttonHarmat);
            this.Controls.Add(this.buttonSzalay);
            this.Controls.Add(this.buttonSzasz);
            this.Controls.Add(this.buttonExit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Bejelentkezes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MaTaekwondo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonSzasz;
        private System.Windows.Forms.Button buttonSzalay;
        private System.Windows.Forms.Button buttonHarmat;
        private System.Windows.Forms.Button buttonMate;
        private System.Windows.Forms.Button buttonSolti;
        private System.Windows.Forms.Button buttonLog;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.TextBox textBoxUname;
        private System.Windows.Forms.TextBox textBoxPwd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}