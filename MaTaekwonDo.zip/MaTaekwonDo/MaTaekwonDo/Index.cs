﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Text;

namespace MaTaekwonDo
{
    public partial class Index : Form
    {
        private bool beJelentkezett = false;
        public Index()
        {
            InitializeComponent();
        }

        private void Index_Load(object sender, EventArgs e)
        {
            buttonDig.Visible = false;
            buttonLicense.Visible = false;
            if (beJelentkezett == true)
            {
                buttonDig.Visible = true;
                buttonLicense.Visible = true;
            }
            toolTipLogin.SetToolTip(buttonDig, "Digitális Anyag");
            toolTipLogin.SetToolTip(buttonExit, "A program bezárása");
            toolTipLogin.SetToolTip(buttonLogin, "Bejelentkezés");
            toolTipLogin.SetToolTip(buttonLicense, "Az alkotóról");
            toolTipLogin.SetToolTip(buttonReg, "Regisztráció");
            toolTipLogin.SetToolTip(buttonWebOldal, "A hivatalos weboldal");
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonReg_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Jelenleg nem elérhető");
        }

        private void buttonWebOldal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Jelenleg nem elérhető");
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            Bejelentkezes b = new Bejelentkezes();
            b.Show();
            this.Hide();
        }
    }
}
