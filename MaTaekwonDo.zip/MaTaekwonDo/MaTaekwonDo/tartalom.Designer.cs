﻿namespace MaTaekwonDo
{
    partial class tartalom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.PictureBox pictureBox1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tartalom));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageAjanlo = new System.Windows.Forms.TabPage();
            this.buttonMentes = new System.Windows.Forms.Button();
            this.buttonSzerkeszt = new System.Windows.Forms.Button();
            this.textBoxAjanlo = new System.Windows.Forms.TextBox();
            this.tabPageBevezeto = new System.Windows.Forms.TabPage();
            this.buttonSzerk = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPagetortenet = new System.Windows.Forms.TabPage();
            this.tabPagematortenet = new System.Windows.Forms.TabPage();
            this.tabPagetanai = new System.Windows.Forms.TabPage();
            this.tabPageeletpontok = new System.Windows.Forms.TabPage();
            this.tabPageMozgasanyag = new System.Windows.Forms.TabPage();
            this.tabPageBazis = new System.Windows.Forms.TabPage();
            this.tabPageEro = new System.Windows.Forms.TabPage();
            this.tabPageForma = new System.Windows.Forms.TabPage();
            this.tabPageFormaSzab = new System.Windows.Forms.TabPage();
            this.tabPageFoKuzdelem = new System.Windows.Forms.TabPage();
            this.tabPageOnvedelem = new System.Windows.Forms.TabPage();
            this.tabPageTores = new System.Windows.Forms.TabPage();
            this.tabPageToresSzab = new System.Windows.Forms.TabPage();
            this.tabPageKuzdelem = new System.Windows.Forms.TabPage();
            this.tabPageKuzSzab = new System.Windows.Forms.TabPage();
            this.tabPageVersenyTaktika = new System.Windows.Forms.TabPage();
            this.tabPageSpecFejl = new System.Windows.Forms.TabPage();
            this.tabPageEdzoterem = new System.Windows.Forms.TabPage();
            this.tabPageOvRend = new System.Windows.Forms.TabPage();
            this.tabPageVizsgaany = new System.Windows.Forms.TabPage();
            this.tabPageOrv = new System.Windows.Forms.TabPage();
            this.tabPageSzotar = new System.Windows.Forms.TabPage();
            this.tabPageKepek = new System.Windows.Forms.TabPage();
            this.buttonVissza = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPageAjanlo.SuspendLayout();
            this.tabPageBevezeto.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = System.Drawing.Color.Transparent;
            pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
            pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            pictureBox1.Location = new System.Drawing.Point(845, 58);
            pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(144, 348);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageAjanlo);
            this.tabControl1.Controls.Add(this.tabPageBevezeto);
            this.tabControl1.Controls.Add(this.tabPagetortenet);
            this.tabControl1.Controls.Add(this.tabPagematortenet);
            this.tabControl1.Controls.Add(this.tabPagetanai);
            this.tabControl1.Controls.Add(this.tabPageeletpontok);
            this.tabControl1.Controls.Add(this.tabPageMozgasanyag);
            this.tabControl1.Controls.Add(this.tabPageBazis);
            this.tabControl1.Controls.Add(this.tabPageEro);
            this.tabControl1.Controls.Add(this.tabPageForma);
            this.tabControl1.Controls.Add(this.tabPageFormaSzab);
            this.tabControl1.Controls.Add(this.tabPageFoKuzdelem);
            this.tabControl1.Controls.Add(this.tabPageOnvedelem);
            this.tabControl1.Controls.Add(this.tabPageTores);
            this.tabControl1.Controls.Add(this.tabPageToresSzab);
            this.tabControl1.Controls.Add(this.tabPageKuzdelem);
            this.tabControl1.Controls.Add(this.tabPageKuzSzab);
            this.tabControl1.Controls.Add(this.tabPageVersenyTaktika);
            this.tabControl1.Controls.Add(this.tabPageSpecFejl);
            this.tabControl1.Controls.Add(this.tabPageEdzoterem);
            this.tabControl1.Controls.Add(this.tabPageOvRend);
            this.tabControl1.Controls.Add(this.tabPageVizsgaany);
            this.tabControl1.Controls.Add(this.tabPageOrv);
            this.tabControl1.Controls.Add(this.tabPageSzotar);
            this.tabControl1.Controls.Add(this.tabPageKepek);
            this.tabControl1.Font = new System.Drawing.Font("News706 BT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 36);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1000, 496);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPageAjanlo
            // 
            this.tabPageAjanlo.AccessibleName = "Ajanlo";
            this.tabPageAjanlo.BackColor = System.Drawing.Color.LightGray;
            this.tabPageAjanlo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tabPageAjanlo.Controls.Add(pictureBox1);
            this.tabPageAjanlo.Controls.Add(this.buttonMentes);
            this.tabPageAjanlo.Controls.Add(this.buttonSzerkeszt);
            this.tabPageAjanlo.Controls.Add(this.textBoxAjanlo);
            this.tabPageAjanlo.Font = new System.Drawing.Font("News706 BT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageAjanlo.Location = new System.Drawing.Point(4, 28);
            this.tabPageAjanlo.Name = "tabPageAjanlo";
            this.tabPageAjanlo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAjanlo.Size = new System.Drawing.Size(992, 464);
            this.tabPageAjanlo.TabIndex = 0;
            this.tabPageAjanlo.Text = "Ajánló";
            this.tabPageAjanlo.ToolTipText = "Ajánló";
            // 
            // buttonMentes
            // 
            this.buttonMentes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.buttonMentes.Font = new System.Drawing.Font("News706 BT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMentes.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonMentes.Location = new System.Drawing.Point(845, 409);
            this.buttonMentes.Name = "buttonMentes";
            this.buttonMentes.Size = new System.Drawing.Size(144, 48);
            this.buttonMentes.TabIndex = 1;
            this.buttonMentes.Text = "Mentés";
            this.buttonMentes.UseVisualStyleBackColor = false;
            // 
            // buttonSzerkeszt
            // 
            this.buttonSzerkeszt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.buttonSzerkeszt.Font = new System.Drawing.Font("News706 BT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSzerkeszt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonSzerkeszt.Location = new System.Drawing.Point(845, 6);
            this.buttonSzerkeszt.Name = "buttonSzerkeszt";
            this.buttonSzerkeszt.Size = new System.Drawing.Size(144, 48);
            this.buttonSzerkeszt.TabIndex = 1;
            this.buttonSzerkeszt.Text = "Szerkesztés";
            this.buttonSzerkeszt.UseVisualStyleBackColor = false;
            // 
            // textBoxAjanlo
            // 
            this.textBoxAjanlo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxAjanlo.Location = new System.Drawing.Point(6, 6);
            this.textBoxAjanlo.Multiline = true;
            this.textBoxAjanlo.Name = "textBoxAjanlo";
            this.textBoxAjanlo.ReadOnly = true;
            this.textBoxAjanlo.Size = new System.Drawing.Size(825, 438);
            this.textBoxAjanlo.TabIndex = 0;
            this.textBoxAjanlo.Text = resources.GetString("textBoxAjanlo.Text");
            // 
            // tabPageBevezeto
            // 
            this.tabPageBevezeto.BackColor = System.Drawing.Color.LightGray;
            this.tabPageBevezeto.Controls.Add(this.buttonSzerk);
            this.tabPageBevezeto.Controls.Add(this.textBox1);
            this.tabPageBevezeto.Font = new System.Drawing.Font("News706 BT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageBevezeto.Location = new System.Drawing.Point(4, 28);
            this.tabPageBevezeto.Name = "tabPageBevezeto";
            this.tabPageBevezeto.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBevezeto.Size = new System.Drawing.Size(992, 464);
            this.tabPageBevezeto.TabIndex = 1;
            this.tabPageBevezeto.Text = "Bevezető";
            // 
            // buttonSzerk
            // 
            this.buttonSzerk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.buttonSzerk.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonSzerk.Location = new System.Drawing.Point(852, 3);
            this.buttonSzerk.Name = "buttonSzerk";
            this.buttonSzerk.Size = new System.Drawing.Size(134, 35);
            this.buttonSzerk.TabIndex = 1;
            this.buttonSzerk.Text = "Szerkesztés";
            this.buttonSzerk.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(6, 3);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(840, 457);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // tabPagetortenet
            // 
            this.tabPagetortenet.Location = new System.Drawing.Point(4, 28);
            this.tabPagetortenet.Name = "tabPagetortenet";
            this.tabPagetortenet.Size = new System.Drawing.Size(992, 479);
            this.tabPagetortenet.TabIndex = 2;
            this.tabPagetortenet.Text = "A Taekwon-do története";
            this.tabPagetortenet.UseVisualStyleBackColor = true;
            // 
            // tabPagematortenet
            // 
            this.tabPagematortenet.Location = new System.Drawing.Point(4, 28);
            this.tabPagematortenet.Name = "tabPagematortenet";
            this.tabPagematortenet.Size = new System.Drawing.Size(1042, 479);
            this.tabPagematortenet.TabIndex = 3;
            this.tabPagematortenet.Text = "A Magyar Taekwon-do története";
            this.tabPagematortenet.UseVisualStyleBackColor = true;
            // 
            // tabPagetanai
            // 
            this.tabPagetanai.Location = new System.Drawing.Point(4, 28);
            this.tabPagetanai.Name = "tabPagetanai";
            this.tabPagetanai.Size = new System.Drawing.Size(1042, 479);
            this.tabPagetanai.TabIndex = 4;
            this.tabPagetanai.Text = "A Taekwon-do tanai";
            this.tabPagetanai.UseVisualStyleBackColor = true;
            // 
            // tabPageeletpontok
            // 
            this.tabPageeletpontok.Location = new System.Drawing.Point(4, 28);
            this.tabPageeletpontok.Name = "tabPageeletpontok";
            this.tabPageeletpontok.Size = new System.Drawing.Size(1042, 479);
            this.tabPageeletpontok.TabIndex = 5;
            this.tabPageeletpontok.Text = "Életpontok";
            this.tabPageeletpontok.UseVisualStyleBackColor = true;
            // 
            // tabPageMozgasanyag
            // 
            this.tabPageMozgasanyag.Location = new System.Drawing.Point(4, 28);
            this.tabPageMozgasanyag.Name = "tabPageMozgasanyag";
            this.tabPageMozgasanyag.Size = new System.Drawing.Size(1042, 479);
            this.tabPageMozgasanyag.TabIndex = 6;
            this.tabPageMozgasanyag.Text = "A Taekwon-do mozgásanyaga";
            this.tabPageMozgasanyag.UseVisualStyleBackColor = true;
            // 
            // tabPageBazis
            // 
            this.tabPageBazis.Location = new System.Drawing.Point(4, 28);
            this.tabPageBazis.Name = "tabPageBazis";
            this.tabPageBazis.Size = new System.Drawing.Size(1042, 479);
            this.tabPageBazis.TabIndex = 7;
            this.tabPageBazis.Text = "Bázis, vagy alapgyakorlatok";
            this.tabPageBazis.UseVisualStyleBackColor = true;
            // 
            // tabPageEro
            // 
            this.tabPageEro.Location = new System.Drawing.Point(4, 28);
            this.tabPageEro.Name = "tabPageEro";
            this.tabPageEro.Size = new System.Drawing.Size(1042, 479);
            this.tabPageEro.TabIndex = 8;
            this.tabPageEro.Text = "Erő és gyorsaság elmélete";
            this.tabPageEro.UseVisualStyleBackColor = true;
            // 
            // tabPageForma
            // 
            this.tabPageForma.Location = new System.Drawing.Point(4, 28);
            this.tabPageForma.Name = "tabPageForma";
            this.tabPageForma.Size = new System.Drawing.Size(1042, 479);
            this.tabPageForma.TabIndex = 9;
            this.tabPageForma.Text = "Formagyakorlat";
            this.tabPageForma.UseVisualStyleBackColor = true;
            // 
            // tabPageFormaSzab
            // 
            this.tabPageFormaSzab.Location = new System.Drawing.Point(4, 28);
            this.tabPageFormaSzab.Name = "tabPageFormaSzab";
            this.tabPageFormaSzab.Size = new System.Drawing.Size(1042, 479);
            this.tabPageFormaSzab.TabIndex = 10;
            this.tabPageFormaSzab.Text = "A formagyakorlat versenyszabályai";
            this.tabPageFormaSzab.UseVisualStyleBackColor = true;
            // 
            // tabPageFoKuzdelem
            // 
            this.tabPageFoKuzdelem.Location = new System.Drawing.Point(4, 28);
            this.tabPageFoKuzdelem.Name = "tabPageFoKuzdelem";
            this.tabPageFoKuzdelem.Size = new System.Drawing.Size(1042, 479);
            this.tabPageFoKuzdelem.TabIndex = 11;
            this.tabPageFoKuzdelem.Text = "Formai Küzdelem";
            this.tabPageFoKuzdelem.UseVisualStyleBackColor = true;
            // 
            // tabPageOnvedelem
            // 
            this.tabPageOnvedelem.Location = new System.Drawing.Point(4, 28);
            this.tabPageOnvedelem.Name = "tabPageOnvedelem";
            this.tabPageOnvedelem.Size = new System.Drawing.Size(1042, 479);
            this.tabPageOnvedelem.TabIndex = 12;
            this.tabPageOnvedelem.Text = "Önvédelmi technikák";
            this.tabPageOnvedelem.UseVisualStyleBackColor = true;
            // 
            // tabPageTores
            // 
            this.tabPageTores.Location = new System.Drawing.Point(4, 28);
            this.tabPageTores.Name = "tabPageTores";
            this.tabPageTores.Size = new System.Drawing.Size(1042, 479);
            this.tabPageTores.TabIndex = 13;
            this.tabPageTores.Text = "Töréstechnika";
            this.tabPageTores.UseVisualStyleBackColor = true;
            // 
            // tabPageToresSzab
            // 
            this.tabPageToresSzab.Location = new System.Drawing.Point(4, 28);
            this.tabPageToresSzab.Name = "tabPageToresSzab";
            this.tabPageToresSzab.Size = new System.Drawing.Size(1042, 479);
            this.tabPageToresSzab.TabIndex = 14;
            this.tabPageToresSzab.Text = "A töréstechnika versenyszabályai";
            this.tabPageToresSzab.UseVisualStyleBackColor = true;
            // 
            // tabPageKuzdelem
            // 
            this.tabPageKuzdelem.Location = new System.Drawing.Point(4, 28);
            this.tabPageKuzdelem.Name = "tabPageKuzdelem";
            this.tabPageKuzdelem.Size = new System.Drawing.Size(1042, 479);
            this.tabPageKuzdelem.TabIndex = 15;
            this.tabPageKuzdelem.Text = "Szabad Küzdelem";
            this.tabPageKuzdelem.UseVisualStyleBackColor = true;
            // 
            // tabPageKuzSzab
            // 
            this.tabPageKuzSzab.Location = new System.Drawing.Point(4, 28);
            this.tabPageKuzSzab.Name = "tabPageKuzSzab";
            this.tabPageKuzSzab.Size = new System.Drawing.Size(1042, 479);
            this.tabPageKuzSzab.TabIndex = 16;
            this.tabPageKuzSzab.Text = "A küzdelem versenyszabályai";
            this.tabPageKuzSzab.UseVisualStyleBackColor = true;
            // 
            // tabPageVersenyTaktika
            // 
            this.tabPageVersenyTaktika.Location = new System.Drawing.Point(4, 28);
            this.tabPageVersenyTaktika.Name = "tabPageVersenyTaktika";
            this.tabPageVersenyTaktika.Size = new System.Drawing.Size(1042, 479);
            this.tabPageVersenyTaktika.TabIndex = 17;
            this.tabPageVersenyTaktika.Text = "Versenytaktika";
            this.tabPageVersenyTaktika.UseVisualStyleBackColor = true;
            // 
            // tabPageSpecFejl
            // 
            this.tabPageSpecFejl.Location = new System.Drawing.Point(4, 28);
            this.tabPageSpecFejl.Name = "tabPageSpecFejl";
            this.tabPageSpecFejl.Size = new System.Drawing.Size(1042, 479);
            this.tabPageSpecFejl.TabIndex = 18;
            this.tabPageSpecFejl.Text = "Speciális képességfejlesztés";
            this.tabPageSpecFejl.UseVisualStyleBackColor = true;
            // 
            // tabPageEdzoterem
            // 
            this.tabPageEdzoterem.Location = new System.Drawing.Point(4, 28);
            this.tabPageEdzoterem.Name = "tabPageEdzoterem";
            this.tabPageEdzoterem.Size = new System.Drawing.Size(1042, 479);
            this.tabPageEdzoterem.TabIndex = 19;
            this.tabPageEdzoterem.Text = "Edzőterem";
            this.tabPageEdzoterem.UseVisualStyleBackColor = true;
            // 
            // tabPageOvRend
            // 
            this.tabPageOvRend.Location = new System.Drawing.Point(4, 28);
            this.tabPageOvRend.Name = "tabPageOvRend";
            this.tabPageOvRend.Size = new System.Drawing.Size(1042, 479);
            this.tabPageOvRend.TabIndex = 20;
            this.tabPageOvRend.Text = "Az övfokozatok Rendje";
            this.tabPageOvRend.UseVisualStyleBackColor = true;
            // 
            // tabPageVizsgaany
            // 
            this.tabPageVizsgaany.Location = new System.Drawing.Point(4, 28);
            this.tabPageVizsgaany.Name = "tabPageVizsgaany";
            this.tabPageVizsgaany.Size = new System.Drawing.Size(1042, 479);
            this.tabPageVizsgaany.TabIndex = 21;
            this.tabPageVizsgaany.Text = "Részletes Vizsgaanyag";
            this.tabPageVizsgaany.UseVisualStyleBackColor = true;
            // 
            // tabPageOrv
            // 
            this.tabPageOrv.Location = new System.Drawing.Point(4, 28);
            this.tabPageOrv.Name = "tabPageOrv";
            this.tabPageOrv.Size = new System.Drawing.Size(1042, 479);
            this.tabPageOrv.TabIndex = 22;
            this.tabPageOrv.Text = "Orvosi jegyzetek";
            this.tabPageOrv.UseVisualStyleBackColor = true;
            // 
            // tabPageSzotar
            // 
            this.tabPageSzotar.Location = new System.Drawing.Point(4, 28);
            this.tabPageSzotar.Name = "tabPageSzotar";
            this.tabPageSzotar.Size = new System.Drawing.Size(1042, 479);
            this.tabPageSzotar.TabIndex = 23;
            this.tabPageSzotar.Text = "Koreai szakszótár";
            this.tabPageSzotar.UseVisualStyleBackColor = true;
            // 
            // tabPageKepek
            // 
            this.tabPageKepek.Location = new System.Drawing.Point(4, 28);
            this.tabPageKepek.Name = "tabPageKepek";
            this.tabPageKepek.Size = new System.Drawing.Size(1042, 479);
            this.tabPageKepek.TabIndex = 24;
            this.tabPageKepek.Text = "Képmelléklet";
            this.tabPageKepek.UseVisualStyleBackColor = true;
            // 
            // buttonVissza
            // 
            this.buttonVissza.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.buttonVissza.Font = new System.Drawing.Font("News706 BT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonVissza.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonVissza.Location = new System.Drawing.Point(12, 534);
            this.buttonVissza.Name = "buttonVissza";
            this.buttonVissza.Size = new System.Drawing.Size(132, 39);
            this.buttonVissza.TabIndex = 2;
            this.buttonVissza.Text = "Vissza";
            this.buttonVissza.UseVisualStyleBackColor = false;
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Transparent;
            this.buttonExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonExit.BackgroundImage")));
            this.buttonExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Location = new System.Drawing.Point(979, 0);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(33, 30);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.UseVisualStyleBackColor = false;
            // 
            // tartalom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1024, 576);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonVissza);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "tartalom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MaTaekwonDo";
            ((System.ComponentModel.ISupportInitialize)(pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPageAjanlo.ResumeLayout(false);
            this.tabPageAjanlo.PerformLayout();
            this.tabPageBevezeto.ResumeLayout(false);
            this.tabPageBevezeto.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageAjanlo;
        private System.Windows.Forms.Button buttonMentes;
        private System.Windows.Forms.Button buttonSzerkeszt;
        private System.Windows.Forms.TextBox textBoxAjanlo;
        private System.Windows.Forms.TabPage tabPageBevezeto;
        private System.Windows.Forms.Button buttonSzerk;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TabPage tabPagetortenet;
        private System.Windows.Forms.TabPage tabPagematortenet;
        private System.Windows.Forms.TabPage tabPagetanai;
        private System.Windows.Forms.TabPage tabPageeletpontok;
        private System.Windows.Forms.TabPage tabPageMozgasanyag;
        private System.Windows.Forms.TabPage tabPageBazis;
        private System.Windows.Forms.TabPage tabPageEro;
        private System.Windows.Forms.TabPage tabPageForma;
        private System.Windows.Forms.TabPage tabPageFormaSzab;
        private System.Windows.Forms.TabPage tabPageFoKuzdelem;
        private System.Windows.Forms.TabPage tabPageOnvedelem;
        private System.Windows.Forms.TabPage tabPageTores;
        private System.Windows.Forms.TabPage tabPageToresSzab;
        private System.Windows.Forms.TabPage tabPageKuzdelem;
        private System.Windows.Forms.TabPage tabPageKuzSzab;
        private System.Windows.Forms.TabPage tabPageVersenyTaktika;
        private System.Windows.Forms.TabPage tabPageSpecFejl;
        private System.Windows.Forms.TabPage tabPageEdzoterem;
        private System.Windows.Forms.TabPage tabPageOvRend;
        private System.Windows.Forms.TabPage tabPageVizsgaany;
        private System.Windows.Forms.TabPage tabPageOrv;
        private System.Windows.Forms.TabPage tabPageSzotar;
        private System.Windows.Forms.TabPage tabPageKepek;
        private System.Windows.Forms.Button buttonVissza;
        private System.Windows.Forms.Button buttonExit;
    }
}